import { NextResponse } from 'next/server';
import { supabaseAdmin } from '../../../../lib/supabase';
import { sendToOwner } from '../../../../lib/telegram';
import { nevaCheckWithdrawStatus } from '../../../../lib/nevapedia';

function formatRupiah(n) { return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(n || 0); }

export async function GET(req) {
  const authHeader = req.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { data: pending } = await supabaseAdmin.from('withdrawals').select('*')
    .eq('type', 'instant').eq('status', 'processing').not('neva_withdraw_id', 'is', null);
  if (!pending || pending.length === 0) return NextResponse.json({ ok: true, checked: 0 });

  let updated = 0;

  for (const wd of pending) {
    try {
      const resp = await nevaCheckWithdrawStatus(wd.neva_withdraw_id);
      const nevaStatus = resp?.status;

      if (nevaStatus === 'success') {
        const { data: rows } = await supabaseAdmin.from('withdrawals')
          .update({ status: 'success', completed_at: new Date().toISOString() })
          .eq('id', wd.id).eq('status', 'processing').select();
        if (rows?.length) {
          updated++;
          await sendToOwner(`✅ *WD INSTAN SUKSES* (nevapedia)\n👤 ${wd.username}\n💸 ${formatRupiah(wd.amount)} → ${wd.operator.toUpperCase()}`);
        }
      } else if (nevaStatus === 'failed') {
        const { data: rows } = await supabaseAdmin.from('withdrawals')
          .update({ status: 'failed', h2h_reason: resp?.admin_note || 'Gagal di provider' })
          .eq('id', wd.id).eq('status', 'processing').select();
        if (rows?.length && !wd.saldo_refunded) {
          await supabaseAdmin.rpc('refund_balance_atomic', { p_user_id: wd.user_id, p_amount: wd.amount + wd.fee });
          await supabaseAdmin.from('withdrawals').update({ saldo_refunded: true }).eq('id', wd.id);
          updated++;
          await sendToOwner(`❌ *WD INSTAN GAGAL - SALDO DIKEMBALIKAN*\n👤 ${wd.username}\n+${formatRupiah(wd.amount + wd.fee)} dikembalikan`);
        }
      }
      // status lain (pending/processing di sisi Nevapedia) -> biarkan, cek lagi nanti
    } catch (e) { console.error(`Cek Nevapedia WD ${wd.id}:`, e.message); }
  }
  return NextResponse.json({ ok: true, checked: pending.length, updated });
}
