import { NextResponse } from 'next/server';
import { supabaseAdmin } from '../../../../lib/supabase';
import { getSession } from '../../../../lib/auth';
import { nevaCheckInvoice } from '../../../../lib/nevapedia';
import { gopayCheckStatus } from '../../../../lib/gopay';
import { sendDepositSuccessNotification, sendToOwner } from '../../../../lib/telegram';

function formatRupiah(n) { return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(n || 0); }

export async function POST(req) {
  const session = getSession();
  if (!session) return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });

  const { deposit_id } = await req.json();
  if (!deposit_id) return NextResponse.json({ success: false, error: 'Deposit ID required' }, { status: 400 });

  const { data: deposit } = await supabaseAdmin.from('deposits').select('*').eq('id', deposit_id).maybeSingle();
  if (!deposit) return NextResponse.json({ success: false, error: 'Deposit not found' }, { status: 404 });
  if (deposit.user_id !== session.id) return NextResponse.json({ success: false, error: 'Access denied' }, { status: 403 });

  if (deposit.status === 'success') return NextResponse.json({ success: true, status: 'success', message: 'Deposit berhasil! Saldo bertambah.' });
  if (deposit.status === 'canceled') return NextResponse.json({ success: true, status: 'canceled', message: 'Deposit dibatalkan' });
  if (deposit.status === 'expired') return NextResponse.json({ success: true, status: 'expired', message: 'Deposit expired' });

  if (new Date() > new Date(deposit.expired_at)) {
    const { data } = await supabaseAdmin.rpc('expire_deposit_atomic', { p_deposit_id: deposit_id });
    if (data && data.length > 0) return NextResponse.json({ success: true, status: 'expired', message: 'Deposit expired' });
    const { data: fresh } = await supabaseAdmin.from('deposits').select('status').eq('id', deposit_id).maybeSingle();
    return NextResponse.json({ success: true, status: fresh?.status || 'expired' });
  }

  // ── Nevapedia: cek real-time via invoice API ──
  if (deposit.provider === 'nevapedia' && deposit.neva_invoice_id) {
    try {
      const inv = await nevaCheckInvoice(deposit.neva_invoice_id);
      if (inv?.status === 'paid') {
        const { data: credited } = await supabaseAdmin.rpc('credit_deposit_atomic', {
          p_deposit_id: deposit_id, p_mutation_key: `neva:${deposit.neva_invoice_id}`
        });
        if (credited && credited.length > 0) {
          const { data: user } = await supabaseAdmin.from('users').select('*').eq('id', deposit.user_id).maybeSingle();
          if (user) {
            await sendDepositSuccessNotification({ ...deposit, status: 'success' }, user, formatRupiah);
            await sendToOwner(`✅ *DEPOSIT BERHASIL* (nevapedia)\n👤 ${user.username}\n+${formatRupiah(deposit.amount)}\n💵 Saldo: ${formatRupiah(user.balance)}`);
          }
          return NextResponse.json({ success: true, status: 'success', message: 'Deposit berhasil! Saldo bertambah.' });
        }
        const { data: fresh } = await supabaseAdmin.from('deposits').select('status').eq('id', deposit_id).maybeSingle();
        return NextResponse.json({ success: true, status: fresh?.status || 'pending' });
      }
    } catch (e) {
      console.error('nevaCheckInvoice error:', e.message);
    }
  }

  // ── GoPay Merchant: cek real-time via casaku check-status ──
  if (deposit.provider === 'gopay' && deposit.trxid_api) {
    try {
      const gp = await gopayCheckStatus(deposit.trxid_api);
      if (gp?.status === 'paid') {
        const { data: credited } = await supabaseAdmin.rpc('credit_deposit_atomic', {
          p_deposit_id: deposit_id, p_mutation_key: `gopay:${deposit.trxid_api}`
        });
        if (credited && credited.length > 0) {
          const { data: user } = await supabaseAdmin.from('users').select('*').eq('id', deposit.user_id).maybeSingle();
          if (user) {
            await sendDepositSuccessNotification({ ...deposit, status: 'success' }, user, formatRupiah);
            await sendToOwner(`✅ *DEPOSIT BERHASIL* (gopay)\n👤 ${user.username}\n+${formatRupiah(deposit.amount)}\n💵 Saldo: ${formatRupiah(user.balance)}`);
          }
          return NextResponse.json({ success: true, status: 'success', message: 'Deposit berhasil! Saldo bertambah.' });
        }
        const { data: fresh } = await supabaseAdmin.from('deposits').select('status').eq('id', deposit_id).maybeSingle();
        return NextResponse.json({ success: true, status: fresh?.status || 'pending' });
      }
    } catch (e) {
      console.error('gopayCheckStatus error:', e.message);
    }
  }

  return NextResponse.json({ success: true, status: 'pending', message: 'Menunggu pembayaran. Auto-cek setiap 30 detik.' });
}
