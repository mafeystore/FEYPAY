import { NextResponse } from 'next/server';
import { supabaseAdmin } from '../../../../lib/supabase';
import { getSession } from '../../../../lib/auth';
import { generateTransactionId, checkRateLimit, getClientIp } from '../../../../lib/security';
import { sendToOwner } from '../../../../lib/telegram';
import { getActiveDepositProvider } from '../../../../lib/settings';
import { nevaCreateInvoice } from '../../../../lib/nevapedia';
import { gopayCreateQris } from '../../../../lib/gopay';
import { getDepositFee } from '../../../../lib/fee';
import axios from 'axios';

const SPAM_PENDING_THRESHOLD = parseInt(process.env.SPAM_PENDING_THRESHOLD || '20');

function formatRupiah(n) {
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(n || 0);
}

async function createViaOrderKuota(nominal) {
  const randomFee = getDepositFee(nominal);
  const totalBayar = nominal + randomFee;
  const apiKeyOrkut = process.env.ORDERKUOTA_API_KEY, usernameOrkut = process.env.ORDERKUOTA_USERNAME, tokenOrkut = process.env.ORDERKUOTA_TOKEN;
  const createUrl = `https://orkut.neofetchoffc.com/?action=createpayment&apikey=${apiKeyOrkut}&username=${usernameOrkut}&amount=${totalBayar}&token=${tokenOrkut}`;
  const response = await axios.get(createUrl, { timeout: 15000 });
  if (!response.data?.status) throw new Error(response.data?.message || 'Gagal membuat QRIS (OrderKuota)');
  const qrImageUrl = response.data.result?.qris_image;
  if (!qrImageUrl) throw new Error('QRIS image tidak ditemukan (OrderKuota)');
  return { provider: 'orderkuota', fee: randomFee, total_bayar: totalBayar, qr_image: qrImageUrl, neva_invoice_id: null, trxid_api: null };
}

async function createViaNevapedia(nominal) {
  const inv = await nevaCreateInvoice(nominal);
  return {
    provider: 'nevapedia',
    fee: inv.fee,
    total_bayar: inv.total,
    qr_image: inv.qris_image,
    neva_invoice_id: inv.invoice_id,
    trxid_api: inv.invoice_id
  };
}

async function createViaGopay(nominal) {
  const randomFee = getDepositFee(nominal);
  const totalBayar = nominal + randomFee;
  const res = await gopayCreateQris(totalBayar);
  return {
    provider: 'gopay',
    fee: randomFee,
    total_bayar: totalBayar,
    qr_image: res.qr_image,
    neva_invoice_id: null,
    trxid_api: res.transaction_id
  };
}

export async function POST(req) {
  const session = getSession();
  if (!session) return NextResponse.json({ success: false, error: 'Unauthorized, silakan login ulang' }, { status: 401 });

  const ok = await checkRateLimit('deposit', getClientIp(req), 10, 60_000);
  if (!ok) return NextResponse.json({ success: false, error: 'Terlalu banyak request deposit dalam 1 menit. Coba lagi sebentar.' }, { status: 429 });

  const { nominal } = await req.json();
  if (!nominal || nominal < 5000) return NextResponse.json({ success: false, error: 'Minimal deposit Rp5.000' }, { status: 400 });
  if (nominal > 1000000) return NextResponse.json({ success: false, error: 'Maksimal deposit Rp1.000.000' }, { status: 400 });

  const { data: user } = await supabaseAdmin.from('users').select('*').eq('id', session.id).maybeSingle();
  if (!user) return NextResponse.json({ success: false, error: 'User tidak ditemukan' }, { status: 404 });
  if (user.suspended) return NextResponse.json({ success: false, error: 'Akun Anda di-suspend. Hubungi admin.' }, { status: 403 });

  const { count: pendingCount } = await supabaseAdmin
    .from('deposits').select('*', { count: 'exact', head: true })
    .eq('user_id', user.id).eq('status', 'pending').gt('expired_at', new Date().toISOString());
  if ((pendingCount || 0) >= SPAM_PENDING_THRESHOLD) {
    return NextResponse.json({ success: false, error: `Anda memiliki ${pendingCount} deposit pending aktif. Batalkan atau tunggu expire.`, pending_count: pendingCount }, { status: 429 });
  }

  const kodeTrx = generateTransactionId('FP');
  const expireTime = new Date(Date.now() + 3600000);

  try {
    const activeProvider = await getActiveDepositProvider();
    let result;
    if (activeProvider === 'nevapedia') result = await createViaNevapedia(nominal);
    else if (activeProvider === 'gopay') result = await createViaGopay(nominal);
    else result = await createViaOrderKuota(nominal);

    const { error } = await supabaseAdmin.from('deposits').insert({
      id: kodeTrx, user_id: user.id, username: user.username, amount: nominal, fee: result.fee,
      total_bayar: result.total_bayar, qr_image: result.qr_image, status: 'pending', source: 'web',
      provider: result.provider, neva_invoice_id: result.neva_invoice_id,
      trxid_api: result.trxid_api, expired_at: expireTime
    });
    if (error) throw new Error(error.message);

    await sendToOwner(`💰 *DEPOSIT WEB BARU* (${result.provider})\n👤 ${user.username}\n💰 ${formatRupiah(nominal)}\n💵 Total: ${formatRupiah(result.total_bayar)}\n🧾 ${kodeTrx}`);

    return NextResponse.json({ success: true, deposit: { id: kodeTrx, amount: nominal, fee: result.fee, total_payment: result.total_bayar, qr_image: result.qr_image, status: 'pending', expired_at: expireTime.getTime() } });
  } catch (e) {
    return NextResponse.json({ success: false, error: e.message }, { status: 500 });
  }
}
