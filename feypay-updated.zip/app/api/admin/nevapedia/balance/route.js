import { NextResponse } from 'next/server';
import { verifyAdminKey } from '../../../../../lib/auth';
import { nevaGetBalance } from '../../../../../lib/nevapedia';

export async function GET(req) {
  if (!verifyAdminKey(req)) return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
  try {
    const data = await nevaGetBalance();
    return NextResponse.json({ success: true, data });
  } catch (e) {
    return NextResponse.json({ success: false, error: e.message }, { status: 500 });
  }
}
