import { NextResponse } from 'next/server';
import { verifyAdminKey } from '../../../../../lib/auth';
import { nevaCreateWithdraw } from '../../../../../lib/nevapedia';
import { sendToOwner } from '../../../../../lib/telegram';

function formatRupiah(n) { return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(n || 0); }

// Cash-out saldo MERCHANT Nevapedia (uang hasil deposit customer yang sudah
// terkumpul di akun Nevapedia kita) ke e-wallet pribadi admin. INI BEDA
// dengan withdraw instant user — ini murni aksi admin, tidak menyentuh
// saldo user manapun di database kita.
export async function POST(req) {
  if (!verifyAdminKey(req)) return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
  const { amount, method, account_number, instant } = await req.json();
  if (!amount || !method || !account_number) {
    return NextResponse.json({ success: false, error: 'amount, method, account_number wajib diisi' }, { status: 400 });
  }
  try {
    const result = await nevaCreateWithdraw({ amount, method, accountNumber: account_number, instant: !!instant });
    await sendToOwner(`🏧 *ADMIN CASH-OUT NEVAPEDIA*\n💸 ${formatRupiah(amount)} → ${method.toUpperCase()}\n📱 ${account_number}\n🧾 ID: ${result.data?.id || '-'}`);
    return NextResponse.json({ success: true, data: result.data });
  } catch (e) {
    return NextResponse.json({ success: false, error: e.message }, { status: 500 });
  }
}
