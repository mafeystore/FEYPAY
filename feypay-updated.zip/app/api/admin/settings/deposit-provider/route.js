import { NextResponse } from 'next/server';
import { verifyAdminKey } from '../../../../../lib/auth';
import { getActiveDepositProvider, setSetting } from '../../../../../lib/settings';

const VALID_PROVIDERS = ['orderkuota', 'nevapedia', 'gopay'];

export async function GET(req) {
  if (!verifyAdminKey(req)) return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
  const active = await getActiveDepositProvider();
  return NextResponse.json({ success: true, active });
}

export async function POST(req) {
  if (!verifyAdminKey(req)) return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
  const { provider } = await req.json();
  if (!VALID_PROVIDERS.includes(provider)) {
    return NextResponse.json({ success: false, error: `provider harus salah satu dari: ${VALID_PROVIDERS.join(', ')}` }, { status: 400 });
  }
  await setSetting('active_deposit_provider', provider);
  return NextResponse.json({ success: true, active: provider });
}
