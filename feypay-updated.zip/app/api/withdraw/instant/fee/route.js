import { NextResponse } from 'next/server';
import { nevaGetWithdrawMethods } from '../../../../../lib/nevapedia';

// Markup KITA sendiri di atas fee Nevapedia — inilah keuntungan withdraw instant.
const OUR_MARKUP = parseInt(process.env.NEVAPEDIA_WITHDRAW_MARKUP || '1000');

export async function GET() {
  try {
    const data = await nevaGetWithdrawMethods();
    const methods = data?.instant_methods || [];
    const result = {};
    methods.forEach((m) => {
      result[m.method] = {
        provider_fee: m.fee,
        markup_fee: OUR_MARKUP,
        total_fee: m.fee + OUR_MARKUP,
        label: m.name,
        min: m.min,
        max: m.max
      };
    });
    return NextResponse.json({ success: true, fees: result });
  } catch (e) {
    return NextResponse.json({ success: false, error: 'Gagal ambil daftar metode withdraw: ' + e.message, fees: {} }, { status: 500 });
  }
}
