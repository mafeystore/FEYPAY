import { NextResponse } from 'next/server';
import { supabaseAdmin } from '../../../../lib/supabase';
import { nevaCheckInvoice } from '../../../../lib/nevapedia';
import { gopayCheckStatus } from '../../../../lib/gopay';
import { sendDepositSuccessNotification, sendToOwner } from '../../../../lib/telegram';

function formatRupiah(n) { return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(n || 0); }

export async function POST(req) {
  const apiKey = req.headers.get('x-api-key');
  const { deposit_id } = await req.json();
  if (!apiKey) return NextResponse.json({ success: false, error: 'API Key required' }, { status: 401 });
  if (!deposit_id) return NextResponse.json({ success: false, error: 'Deposit ID required' }, { status: 400 });

  const { data: user } = await supabaseAdmin.from('users').select('id').eq('api_key', apiKey).maybeSingle();
  if (!user) return NextResponse.json({ success: false, error: 'Invalid API Key' }, { status: 401 });

  const { data: deposit } = await supabaseAdmin.from('deposits').select('*').eq('id', deposit_id).maybeSingle();
  if (!deposit) return NextResponse.json({ success: false, error: 'Deposit not found' }, { status: 404 });
  if (deposit.user_id !== user.id) return NextResponse.json({ success: false, error: 'Access denied' }, { status: 403 });
  if (deposit.status === 'success') return NextResponse.json({ success: true, status: 'success', message: 'Deposit berhasil!' });
  if (deposit.status === 'canceled') return NextResponse.json({ success: true, status: 'canceled' });

  if (new Date() > new Date(deposit.expired_at) && deposit.status === 'pending') {
    const { data } = await supabaseAdmin.rpc('expire_deposit_atomic', { p_deposit_id: deposit_id });
    if (data?.length) return NextResponse.json({ success: true, status: 'expired' });
  }

  // ── Nevapedia ──
  if (deposit.provider === 'nevapedia' && deposit.neva_invoice_id) {
    try {
      const inv = await nevaCheckInvoice(deposit.neva_invoice_id);
      if (inv?.status === 'paid') {
        const { data: credited } = await supabaseAdmin.rpc('credit_deposit_atomic', {
          p_deposit_id: deposit_id, p_mutation_key: `neva:${deposit.neva_invoice_id}`
        });
        if (credited && credited.length > 0) {
          const { data: fullUser } = await supabaseAdmin.from('users').select('*').eq('id', deposit.user_id).maybeSingle();
          if (fullUser) {
            await sendDepositSuccessNotification({ ...deposit, status: 'success' }, fullUser, formatRupiah);
            await sendToOwner(`✅ *DEPOSIT BERHASIL (API)* (nevapedia)\n👤 ${fullUser.username}\n+${formatRupiah(deposit.amount)}`);
          }
          return NextResponse.json({ success: true, status: 'success', message: 'Deposit berhasil!' });
        }
        const { data: fresh } = await supabaseAdmin.from('deposits').select('status').eq('id', deposit_id).maybeSingle();
        return NextResponse.json({ success: true, status: fresh?.status || 'pending' });
      }
    } catch (e) {
      console.error('nevaCheckInvoice error:', e.message);
    }
  }

  // ── GoPay Merchant ──
  if (deposit.provider === 'gopay' && deposit.trxid_api) {
    try {
      const gp = await gopayCheckStatus(deposit.trxid_api);
      if (gp?.status === 'paid') {
        const { data: credited } = await supabaseAdmin.rpc('credit_deposit_atomic', {
          p_deposit_id: deposit_id, p_mutation_key: `gopay:${deposit.trxid_api}`
        });
        if (credited && credited.length > 0) {
          const { data: fullUser } = await supabaseAdmin.from('users').select('*').eq('id', deposit.user_id).maybeSingle();
          if (fullUser) {
            await sendDepositSuccessNotification({ ...deposit, status: 'success' }, fullUser, formatRupiah);
            await sendToOwner(`✅ *DEPOSIT BERHASIL (API)* (gopay)\n👤 ${fullUser.username}\n+${formatRupiah(deposit.amount)}`);
          }
          return NextResponse.json({ success: true, status: 'success', message: 'Deposit berhasil!' });
        }
        const { data: fresh } = await supabaseAdmin.from('deposits').select('status').eq('id', deposit_id).maybeSingle();
        return NextResponse.json({ success: true, status: fresh?.status || 'pending' });
      }
    } catch (e) {
      console.error('gopayCheckStatus error:', e.message);
    }
  }

  return NextResponse.json({ success: true, status: deposit.status || 'pending', message: 'Menunggu pembayaran' });
}
