import { NextResponse } from 'next/server';
import { supabaseAdmin } from '../../../../lib/supabase';
import { generateTransactionId, checkRateLimit, getClientIp } from '../../../../lib/security';
import { tgSendPhoto } from '../../../../lib/telegram';
import { getActiveDepositProvider } from '../../../../lib/settings';
import { nevaCreateInvoice } from '../../../../lib/nevapedia';
import { gopayCreateQris } from '../../../../lib/gopay';
import { getDepositFee } from '../../../../lib/fee';
import axios from 'axios';

const SPAM_PENDING_THRESHOLD = parseInt(process.env.SPAM_PENDING_THRESHOLD || '20');
function formatRupiah(n) { return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(n || 0); }

async function createViaOrderKuota(nominal) {
  const randomFee = getDepositFee(nominal);
  const totalBayar = nominal + randomFee;
  const url = `https://orkut.neofetchoffc.com/?action=createpayment&apikey=${process.env.ORDERKUOTA_API_KEY}&username=${process.env.ORDERKUOTA_USERNAME}&amount=${totalBayar}&token=${process.env.ORDERKUOTA_TOKEN}`;
  const r = await axios.get(url, { timeout: 15000 });
  if (!r.data?.status) throw new Error(r.data?.message || 'Gagal membuat QRIS');
  const qrImageUrl = r.data.result?.qris_image;
  if (!qrImageUrl) throw new Error('QRIS image tidak ditemukan');
  return { provider: 'orderkuota', fee: randomFee, total_bayar: totalBayar, qr_image: qrImageUrl, neva_invoice_id: null, trxid_api: r.data.result?.trxid };
}

async function createViaNevapedia(nominal) {
  const inv = await nevaCreateInvoice(nominal);
  return { provider: 'nevapedia', fee: inv.fee, total_bayar: inv.total, qr_image: inv.qris_image, neva_invoice_id: inv.invoice_id, trxid_api: inv.invoice_id };
}

async function createViaGopay(nominal) {
  const randomFee = getDepositFee(nominal);
  const totalBayar = nominal + randomFee;
  const res = await gopayCreateQris(totalBayar);
  return { provider: 'gopay', fee: randomFee, total_bayar: totalBayar, qr_image: res.qr_image, neva_invoice_id: null, trxid_api: res.transaction_id };
}

export async function POST(req) {
  const ok = await checkRateLimit('deposit', getClientIp(req), 10, 60_000);
  if (!ok) return NextResponse.json({ success: false, error: 'Terlalu banyak request dalam 1 menit.' }, { status: 429 });

  const apiKey = req.headers.get('x-api-key');
  if (!apiKey) return NextResponse.json({ success: false, error: 'API Key required' }, { status: 401 });

  const { amount } = await req.json();
  if (!amount || amount < 5000) return NextResponse.json({ success: false, error: 'Minimal deposit Rp5.000' }, { status: 400 });
  if (amount > 1000000) return NextResponse.json({ success: false, error: 'Maksimal deposit Rp1.000.000' }, { status: 400 });

  const { data: user } = await supabaseAdmin.from('users').select('*').eq('api_key', apiKey).maybeSingle();
  if (!user) return NextResponse.json({ success: false, error: 'Invalid API Key' }, { status: 401 });
  if (user.suspended) return NextResponse.json({ success: false, error: 'Akun Anda di-suspend.' }, { status: 403 });

  const { count } = await supabaseAdmin.from('deposits').select('*', { count: 'exact', head: true })
    .eq('user_id', user.id).eq('status', 'pending').gt('expired_at', new Date().toISOString());
  if ((count || 0) >= SPAM_PENDING_THRESHOLD)
    return NextResponse.json({ success: false, error: `Terlalu banyak deposit pending (${count}).`, pending_count: count }, { status: 429 });

  const kodeTrx = generateTransactionId('FP'), expireTime = new Date(Date.now() + 3600000);

  try {
    const activeProvider = await getActiveDepositProvider();
    let result;
    if (activeProvider === 'nevapedia') result = await createViaNevapedia(amount);
    else if (activeProvider === 'gopay') result = await createViaGopay(amount);
    else result = await createViaOrderKuota(amount);

    await supabaseAdmin.from('deposits').insert({
      id: kodeTrx, trxid_api: result.trxid_api, user_id: user.id, username: user.username,
      amount, fee: result.fee, total_bayar: result.total_bayar, qr_image: result.qr_image, status: 'pending',
      source: 'api', provider: result.provider, neva_invoice_id: result.neva_invoice_id, expired_at: expireTime
    });

    await tgSendPhoto(process.env.ADMIN_TELEGRAM_ID, result.qr_image, `💰 *DEPOSIT API* (${result.provider})\n👤 ${user.username}\n💰 ${formatRupiah(amount)}\n💵 Total: ${formatRupiah(result.total_bayar)}\n🧾 ${kodeTrx}`);

    return NextResponse.json({ success: true, deposit: { id: kodeTrx, amount, fee: result.fee, total_payment: result.total_bayar, qr_image: result.qr_image, status: 'pending', expired_at: expireTime.getTime() } });
  } catch (e) {
    return NextResponse.json({ success: false, error: e.message }, { status: 500 });
  }
}
