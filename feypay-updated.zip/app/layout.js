export const metadata = {
  title: 'FeyPay Payment Gateway',
  description: 'Payment Gateway API'
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
