-- ============================================================
-- MIGRATION: Nevapedia payment provider
-- Jalankan ini di Supabase SQL Editor (Project > SQL Editor).
-- Aman dijalankan berkali-kali (semua pakai IF NOT EXISTS / ON CONFLICT).
-- TIDAK menghapus/mengubah data & kolom yang sudah ada.
-- ============================================================

-- ---------- SETTINGS (key-value, buat pengaturan admin) ----------
create table if not exists settings (
  key         text primary key,
  value       text,
  updated_at  timestamptz not null default now()
);

-- Default: provider deposit aktif tetap OrderKuota (tidak berubah otomatis
-- setelah migration ini, admin yang pilih manual dari panel admin).
insert into settings (key, value)
values ('active_deposit_provider', 'orderkuota')
on conflict (key) do nothing;

-- ---------- DEPOSITS: tambah kolom provider tracking ----------
alter table deposits add column if not exists provider text not null default 'orderkuota';
alter table deposits add column if not exists neva_invoice_id text;
create index if not exists idx_deposits_neva_invoice on deposits(neva_invoice_id);

-- ---------- WITHDRAWALS: tambah kolom provider tracking ----------
alter table withdrawals add column if not exists provider text;
alter table withdrawals add column if not exists neva_withdraw_id text;
alter table withdrawals add column if not exists neva_fee bigint;
create index if not exists idx_wd_neva_id on withdrawals(neva_withdraw_id);

-- Tandai withdrawals lama yang instant sebagai 'h2h' (biar konsisten,
-- withdraw instant BARU akan selalu 'nevapedia' setelah update ini)
update withdrawals set provider = 'h2h' where type = 'instant' and provider is null;
